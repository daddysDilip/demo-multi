<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
       
        <div>
             {!!html_entity_decode($con)!!}

        </div>

    </body>
</html>